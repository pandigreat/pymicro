from distutils.core import setup
setup( 
 name = 'Request', 
 version = '1.0.0', 
 py_modules = ['Request'], 
 author = 'Edison',
 description = 'A simple printer of nester lists' )