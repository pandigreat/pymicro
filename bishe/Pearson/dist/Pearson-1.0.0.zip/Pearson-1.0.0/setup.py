from distutils.core import setup 
setup( 
 name = 'Pearson', 
 version = '1.0.0', 
 py_modules = ['Pearson'], 
 author = 'Edison',
 description = 'A simple printer of nester lists' )