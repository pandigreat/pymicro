import math

def peasonr(matrix):#x-axis is time series of a nodes
    nrows = len(matrix)
    ncols = len(matrix[0])
    n = ncols * 1.0
    res = [[0 for i in range(nrows)] for j in range(nrows)]
    for i in range(nrows):
            idx = i + 1
            for j in range(idx, nrows):
                    a = b = c = f = e = 0;
                    for k in range(0, ncols):
                            a += matrix[i][k] * matrix[j][k]; #sigma xy
                            b += matrix[i][k]; #sigma x
                            c += matrix[j][k]; #sigma y
                            e += matrix[i][k] * matrix[i][k]; #sigma xx
                            f += matrix[j][k] * matrix[j][k]; #sigma yy
                    
                    para1 = a
                    para2 = b * c / n
                    para3 = e
                    para4 = b * b / n
                    para5 = f;
                    para6 = c * c / n
                    
                    r1 = para1 - para2
                    r2 = (para3 - para4) * (para5 - para6)
                    r2 = math.sqrt(r2)
                    r = 1.0 * r1 / r2 
                    res[i][j] = res[j][i] = r * 1.00000
    return res
    
